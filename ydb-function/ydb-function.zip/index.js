const ydb = require('ydb-sdk');

// Карта настроек. Сюда мы впишем адреса баз.
// ВАЖНО: Позже вы сможете менять эти данные через переменные в облаке.
const DATABASES = {
  // Настройки для базы Админа
  'admin': {
    endpoint: process.env.ADMIN_YDB_ENDPOINT,
    database: process.env.ADMIN_YDB_DATABASE,
  },
  // Настройки для базы Клиента (Пример)
  'client': {
    endpoint: process.env.CLIENT_YDB_ENDPOINT,
    database: process.env.CLIENT_YDB_DATABASE,
  }
  // Если клиентов будет много, проще хранить их список в отдельной таблице или сделать отдельные переменные.
};

// Драйверы для подключения (создаются один раз для скорости)
let drivers = {};
let pools = {};

async function getPool(dbType) {
  // Если уже подключились, возвращаем готовое соединение
  if (pools[dbType]) return pools[dbType];

  const config = DATABASES[dbType];
  if (!config || !config.endpoint || !config.database) {
    throw new Error(`База данных для "${dbType}" не настроена. Проверьте переменные окружения.`);
  }

  // Создаём драйвер YDB
  const driver = new ydb.Driver({
    endpoint: config.endpoint,
    database: config.database,
    // Авторизация через сервисный аккаунт (безопасно, так как код в облаке)
    authService: new ydb.MetadataAuthService()
  });

  await driver.ready(10000); // Ждём подключения
  const pool = new ydb.SessionPool(driver);
  
  drivers[dbType] = driver;
  pools[dbType] = pool;
  return pool;
}

exports.handler = async (event, context) => {
  // Заголовки для безопасности (чтобы ваш сайт мог делать запросы)
  const headers = {
    'Access-Control-Allow-Origin': '*', // В будущем можно заменить на адрес вашего сайта
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  // Обработка предварительного запроса от браузера
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Получаем данные из запроса
    const body = JSON.parse(event.body || '{}');
    const { query, orgType } = body; // orgType - это 'admin' или 'client'
    
    // Если не указали тип, считаем что админ
    const dbType = orgType || 'admin'; 

    // Получаем соединение с нужной базой
    const pool = await getPool(dbType);

    // Выполняем запрос в YDB
    const result = await pool.retryOperation(async (session) => {
      return session.executeQuery(query, {}, { commitTx: true });
    });

    // Преобразуем ответ YDB в понятный для сайта формат (упрощённо)
    // В реальной жизни структура может быть сложнее, но для начала сойдёт.
    const rows = [];
    if (result.resultSets && result.resultSets[0]) {
      // Это упрощённый пример, в YDB данные могут быть в другом виде.
      // Если не заработает сразу, скажите, я помогу разобрать структуру.
      rows.push({ info: "Запрос выполнен, но данные нужно распарсить" });
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ rows })
    };

  } catch (err) {
    console.error('Ошибка:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};